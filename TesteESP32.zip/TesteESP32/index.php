<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ... resto do seu código que passei antes ...
$host = "localhost";
$user = "root";
$pass = "root";
$db   = "sistema_carrinho";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Falha na conexão com o banco de dados: " . $conn->connect_error);
}

$mensagem = "";

// Processa o envio do formulário de pedido
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['sala'])) {
    $sala = $conn->real_escape_string($_POST['sala']);
    
    // Cancela pedidos pendentes anteriores para não acumular erros
    $conn->query("UPDATE pedidos SET status_pedido = 'CANCELADO' WHERE status_pedido = 'PENDENTE'");
    
    // Insere o novo pedido
    $sql = "INSERT INTO pedidos (sala_destino, status_pedido) VALUES ('$sala', 'PENDENTE')";
    if ($conn->query($sql) === TRUE) {
        $mensagem = "<div class='sucesso'>Pedido enviado! Carrinho chamado para a <strong>$sala</strong>.</div>";
    } else {
        $mensagem = "<div class='erro'>Erro ao processar pedido.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel de Controle - Carrinho Logístico</title>
    <style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f4f6f9;
        margin: 0;
        padding: 20px;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }

    .container {
        background-color: white;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 450px;
        text-align: center;
    }

    h1 {
        color: #333;
        margin-bottom: 10px;
        font-size: 24px;
    }

    p {
        color: #666;
        font-size: 14px;
        margin-bottom: 25px;
    }

    select {
        width: 100%;
        padding: 12px;
        border: 2px solid #ddd;
        border-radius: 8px;
        font-size: 16px;
        margin-bottom: 20px;
        outline: none;
        transition: border-color 0.3s;
    }

    select:focus {
        border-color: #007bff;
    }

    button {
        width: 100%;
        padding: 14px;
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        transition: background 0.2s;
    }

    button:hover {
        background-color: #0056b3;
    }

    .sucesso {
        background-color: #d4edda;
        color: #155724;
        padding: 12px;
        border-radius: 6px;
        margin-bottom: 20px;
        font-size: 14px;
        text-align: left;
        border-left: 5px solid #28a745;
    }

    .erro {
        background-color: #f8d7da;
        color: #721c24;
        padding: 12px;
        border-radius: 6px;
        margin-bottom: 20px;
        font-size: 14px;
        text-align: left;
        border-left: 5px solid #dc3545;
    }
    </style>
</head>

<body>

    <div class="container">
        <h1>Solicitar Carrinho</h1>
        <p>Selecione o destino de entrega do objeto artesanal</p>

        <?php echo $mensagem; ?>

        <form method="POST" action="">
            <label for="sala"
                style="display:block; text-align:left; margin-bottom:8px; font-weight:bold; color:#444;">Selecione a
                Sala:</label>
            <select name="sala" id="sala" required>
                <option value="" disabled selected>Escolha o destino...</option>
                <option value="SALA_A">Sala A - Laboratório</option>
                <option value="SALA_B">Sala B - Diretoria</option>
                <option value="SALA_C">Sala C - Biblioteca</option>
            </select>

            <button type="submit">Enviar Chamado</button>
        </form>
    </div>

</body>

</html>
<?php $conn->close(); ?>