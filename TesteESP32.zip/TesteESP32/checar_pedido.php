<?php
header("Content-Type: text/plain");

$host = "localhost";
$user = "root"; 
$pass = "root";
$db   = "sistema_carrinho";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("ERRO_BD");
}

// Busca o pedido pendente mais recente
$sql = "SELECT id, sala_destino FROM pedidos WHERE status_pedido = 'PENDENTE' ORDER BY id ASC LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $id_pedido = $row['id'];
    $sala = $row['sala_destino'];
    
    // Retorna apenas o nome da sala para o ESP32 (Ex: SALA_A)
    echo $sala;
    
    // Atualiza o status para 'EM_ANDAMENTO' para o ESP32 não ler o mesmo pedido duas vezes
    $conn->query("UPDATE pedidos SET status_pedido = 'EM_ANDAMENTO' WHERE id = $id_pedido");
} else {
    // Se não houver novos pedidos, responde com "NENHUM"
    echo "NENHUM";
}

$conn->close();
?>